import"./style-D5_demIi.js";import{s as m}from"./version-i07ig4AE.js";m();
