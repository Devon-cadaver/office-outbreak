import"./style-H_2n5qVV.js";import{s as m}from"./version-BrIk9HB1.js";m();
