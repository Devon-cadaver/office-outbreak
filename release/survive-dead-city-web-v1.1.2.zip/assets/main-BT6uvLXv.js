import"./style-D5_demIi.js";import{s as m}from"./version-D4SU1rrs.js";m();
