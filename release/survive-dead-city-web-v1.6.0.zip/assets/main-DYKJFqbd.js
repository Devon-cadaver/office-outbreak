import"./style-H_2n5qVV.js";import{s as m}from"./version-C-3-RR6v.js";m();
