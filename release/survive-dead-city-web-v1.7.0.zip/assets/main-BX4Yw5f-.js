import"./style-H_2n5qVV.js";import{s as m}from"./version-BmDV6xMa.js";m();
