import"./style-D5_demIi.js";import{s as m}from"./version-C91v4qkB.js";m();
