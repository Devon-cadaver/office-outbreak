import"./style-D5_demIi.js";import{s as m}from"./version-BdeNJKfW.js";m();
