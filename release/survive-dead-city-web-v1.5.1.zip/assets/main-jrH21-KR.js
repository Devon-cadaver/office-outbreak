import"./style-D5_demIi.js";import{s as m}from"./version-Dw8vjxjv.js";m();
