import"./style-H_2n5qVV.js";import{s as m}from"./version-4sE6UDH4.js";m();
