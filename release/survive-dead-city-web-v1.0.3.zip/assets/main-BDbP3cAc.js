import"./style-D5_demIi.js";import{s as m}from"./version-B8LzjEYS.js";m();
