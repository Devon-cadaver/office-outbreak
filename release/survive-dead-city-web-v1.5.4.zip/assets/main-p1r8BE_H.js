import"./style-D5_demIi.js";import{s as m}from"./version-DUEOtJMF.js";m();
