import"./style-D5_demIi.js";import{s as m}from"./version-jDevk3qo.js";m();
