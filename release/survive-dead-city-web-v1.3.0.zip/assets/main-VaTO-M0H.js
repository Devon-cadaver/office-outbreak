import"./style-D5_demIi.js";import{s as m}from"./version-DpA3oTFp.js";m();
