import"./style-D5_demIi.js";import{s as m}from"./version-BbNk_F7r.js";m();
