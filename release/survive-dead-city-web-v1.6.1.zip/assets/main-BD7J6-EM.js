import"./style-H_2n5qVV.js";import{s as m}from"./version-D339wbo5.js";m();
