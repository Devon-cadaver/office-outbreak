import"./style-D5_demIi.js";import{s as m}from"./version-BcgzljXo.js";m();
