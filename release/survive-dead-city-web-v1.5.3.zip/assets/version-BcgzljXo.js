const n="1.5.3",o=n;function s(t=document.body){const e=document.createElement("div");return e.className="ver",e.textContent="v"+o,t.appendChild(e),e}export{o as V,s};
