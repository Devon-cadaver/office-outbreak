const n="1.16.2",o=n;function s(t=document.body){const e=document.createElement("div");return e.className="ver",e.textContent="v"+o,t.appendChild(e),e}export{o as V,s};
