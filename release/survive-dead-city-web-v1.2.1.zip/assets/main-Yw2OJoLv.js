import"./style-D5_demIi.js";import{s as m}from"./version-D7JLRzO0.js";m();
